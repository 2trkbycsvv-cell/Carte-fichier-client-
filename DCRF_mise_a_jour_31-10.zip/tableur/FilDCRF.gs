/**
 * FIL DCRF — synchro automatique du tableur vers l'appli DCRF
 * ------------------------------------------------------------
 * Toutes les 5 minutes, ce script compare le tableur avec sa version précédente
 * et envoie à l'appli les nouveautés : ventes, annulations, poses, SAV,
 * financements, factures, encaissements, podium, objectifs, bilan de la semaine.
 * Il envoie aussi les statistiques du jour / semaine / mois pour l'espace Coach.
 *
 * Installation (une seule fois) : choisir la fonction « installerFilDCRF » en haut, puis Exécuter.
 */

const FIL_URL = "https://dcrf.2trkbycsvv.workers.dev/api/auto";
const FIL_CLE = "ciHzrc2DBoqixbLMuPdRSzVLvOuKTzYDs-jM-glP"; // même valeur que SYNC_KEY dans Cloudflare
const FIL_ETAT = "_fil_auto";                                // onglet caché qui garde la mémoire du script
const FIL_ORGAS = ["Sofinco", "Cetelem", "Franfinance", "Domofinance", "Cofidis", "Projexio"];

/* ===================== Menu d'installation ===================== */

function installerFilDCRF() {
  ScriptApp.getProjectTriggers().forEach(function (t) {
    if (t.getHandlerFunction() === "synchroFilDCRF") ScriptApp.deleteTrigger(t);
  });
  const test = filEnvoyer_({ test: true });
  if (!test.ok) throw new Error("L'appli ne répond pas : " + test.msg);
  // Premier passage : on mémorise l'état actuel sans rien envoyer (pas d'avalanche d'anciennes ventes)
  const etat = filEtatActuel_();
  etat.init = true;
  filSauver_(etat);
  ScriptApp.newTrigger("synchroFilDCRF").timeBased().everyMinutes(5).create();
  filEnvoyer_({ evenements: [], stats: filStats_() });
  Logger.log("✅ Synchro installée : le fil de l'appli se met à jour toutes les 5 minutes.");
}

function arreterFilDCRF() {
  ScriptApp.getProjectTriggers().forEach(function (t) {
    if (t.getHandlerFunction() === "synchroFilDCRF") ScriptApp.deleteTrigger(t);
  });
  Logger.log("Synchro arrêtée.");
}

function testerFilDCRF() {
  const r = filEnvoyer_({ test: true });
  Logger.log(r.ok ? "✅ Connexion à l'appli OK" : "❌ " + r.msg);
}

/* ===================== Synchro ===================== */

function synchroFilDCRF() {
  const lock = LockService.getScriptLock();
  if (!lock.tryLock(20000)) return;
  try {
    const avant = filCharger_();
    const apres = filEtatActuel_();
    if (!avant) { filSauver_(apres); return; }
    const evts = filComparer_(avant, apres);
    const stats = filStats_();
    for (let i = 0; i < Math.max(1, evts.length); i += 100) {
      const r = filEnvoyer_({ evenements: evts.slice(i, i + 100), stats: i === 0 ? stats : undefined });
      if (!r.ok) { Logger.log("Envoi refusé, nouvel essai dans 5 min : " + r.msg); return; }
    }
    filSauver_(apres);
    if (evts.length) Logger.log(evts.length + " événement(s) envoyé(s)");
  } finally {
    lock.releaseLock();
  }
}

/* ===================== Lecture du tableur ===================== */

function filLire_(nom) {
  const sh = SpreadsheetApp.getActive().getSheetByName(nom);
  if (!sh || sh.getLastRow() < 2) return [];
  return sh.getRange(2, 1, sh.getLastRow() - 1, sh.getLastColumn()).getValues();
}
function filTz_() { return SpreadsheetApp.getActive().getSpreadsheetTimeZone() || "Europe/Paris"; }
function filIso_(d) { return d instanceof Date ? Utilities.formatDate(d, filTz_(), "yyyy-MM-dd") : ""; }
function filMois_(d) { return Utilities.formatDate(d, filTz_(), "yyyy-MM"); }
function filNum_(v) {
  if (typeof v === "number") return v;
  const n = parseFloat(String(v || "").replace(/[^\d,.-]/g, "").replace(",", "."));
  return isNaN(n) ? 0 : n;
}
function filNom_(s) { s = String(s || "").trim().toLowerCase(); return s.charAt(0).toUpperCase() + s.slice(1); }
function filBase_(c) { return String(c || "").replace(/\s*\((.|\n)*\)\s*$/, "").trim(); }
function filNomCle_(c) {
  const b = filBase_(c);
  if (/^à compléter/i.test(b)) return "";
  const m = b.match(/[A-Za-zÀ-ÿ'-]{3,}/);
  return m ? m[0] : "";
}
function filVendeurs_(liste, equipe) {
  return liste.map(function (n) {
    const k = String(n || "").trim().toUpperCase();
    const e = equipe[k] || {};
    return { nom: filNom_(k), email: e.email || "" };
  });
}
function filEquipe_() {
  const eq = {};
  filLire_("Équipe").forEach(function (r) {
    const n = String(r[0] || "").trim().toUpperCase();
    if (n && !/emplacement|colonne/i.test(n)) eq[n] = { obj: filNum_(r[2]), email: String(r[4] || "").trim(), groupe: String(r[5] || "") };
  });
  return eq;
}
function filEur_(n) { return Math.round(n).toLocaleString("fr-FR").replace(/ | /g, " ") + " €"; }

/** Dossiers de vente regroupés par référence (une vente en binôme = 2 lignes, 1 dossier) */
function filDossiers_() {
  const d = {};
  filLire_("Ventes").forEach(function (r) {
    if (!r[0] && !r[2]) return;
    const date = r[0] instanceof Date ? r[0] : null;
    const ref = String(r[24] || "").trim();
    const key = ref || (filIso_(date) + "|" + filBase_(r[2]).toUpperCase());
    const x = d[key] || (d[key] = { key: key, ref: ref, date: date, client: filBase_(r[2]), ville: String(r[4] || ""), canal: String(r[3] || ""),
      pay: String(r[8] || ""), prod: String(r[9] || ""), motif: String(r[21] || ""), ca: 0, vendeurs: [], lignes: [] });
    x.ca += filNum_(r[7]);
    const v = String(r[1] || "").trim().toUpperCase();
    if (v && x.vendeurs.indexOf(v) < 0) x.vendeurs.push(v);
    x.lignes.push({ com: v, ca: filNum_(r[7]), statut: String(r[12] || ""), date: date });
    if (!x.motif && r[21]) x.motif = String(r[21]);
  });
  Object.keys(d).forEach(function (k) { d[k].annule = d[k].lignes.every(function (l) { return l.statut === "Annulé"; }); });
  return d;
}

/** Photo de l'état actuel, comparée à chaque passage */
function filEtatActuel_() {
  const dos = {}, pos = {}, enc = {};
  const D = filDossiers_();
  Object.keys(D).forEach(function (k) { dos[k] = D[k].annule ? 1 : 0; });
  filLire_("Poses").forEach(function (r) {
    if (!r[0]) return;
    pos[String(r[0]).trim() + "|" + filBase_(r[1]).toUpperCase()] = { s: String(r[8] || ""), d: filIso_(r[9]) };
  });
  filLire_("Encaissements").forEach(function (r) {
    if (!r[0]) return;
    enc[String(r[0]).trim()] = { s: String(r[5] || ""), m: filNum_(r[9]) };
  });
  const cl = filClassement_();
  return { dos: dos, pos: pos, enc: enc, mois: cl.mois, podium: cl.podium, obj: cl.atteints, objEq: cl.equipeAtteint ? 1 : 0, bilan: filCleSemaine_(new Date()) };
}

function filClassement_() {
  const eq = filEquipe_();
  const now = new Date(), mois = filMois_(now);
  const ca = {};
  filLire_("Ventes").forEach(function (r) {
    if (!(r[0] instanceof Date) || filMois_(r[0]) !== mois || r[12] === "Annulé") return;
    const v = String(r[1] || "").trim().toUpperCase();
    if (v) ca[v] = (ca[v] || 0) + filNum_(r[7]);
  });
  const rang = Object.keys(ca).filter(function (v) { return ca[v] > 0; }).sort(function (a, b) { return ca[b] - ca[a]; });
  const atteints = {};
  let tot = 0, totObj = 0;
  Object.keys(eq).forEach(function (v) { totObj += eq[v].obj || 0; });
  Object.keys(ca).forEach(function (v) { tot += ca[v]; if (eq[v] && eq[v].obj && ca[v] >= eq[v].obj) atteints[v] = 1; });
  return { mois: mois, ca: ca, eq: eq, rang: rang, podium: rang.slice(0, 3).join(","), atteints: atteints, tot: tot, totObj: totObj, equipeAtteint: totObj > 0 && tot >= totObj };
}

function filCleSemaine_(d) {
  const lundi = new Date(d.getFullYear(), d.getMonth(), d.getDate() - ((d.getDay() + 6) % 7));
  return filIso_(lundi);
}

/* ===================== Détection des nouveautés ===================== */

function filComparer_(A, B) {
  const ev = [];
  const D = filDossiers_(), eq = filEquipe_();
  const vend = function (liste) { return filVendeurs_(liste, eq); };

  // Ventes et annulations
  Object.keys(D).forEach(function (k) {
    const x = D[k], avant = A.dos[k];
    const base = { client: x.client, nom_cle: filNomCle_(x.client), ville: x.ville, montant: Math.round(x.ca * 100) / 100, vendeurs: vend(x.vendeurs) };
    if (avant === undefined && !x.annule) {
      ev.push(Object.assign({}, base, { type: "vente", cle: "vente|" + k,
        commentaire: [x.prod, x.pay, x.canal].filter(String).join(" · ") }));
    }
    if (avant === 0 && x.annule) {
      ev.push(Object.assign({}, base, { type: "annulation", cle: "annul|" + k, commentaire: x.motif || "" }));
    }
  });

  // Poses et SAV
  filLire_("Poses").forEach(function (r) {
    if (!r[0]) return;
    const ref = String(r[0]).trim(), k = ref + "|" + filBase_(r[1]).toUpperCase();
    const s = String(r[8] || ""), d = filIso_(r[9]), av = A.pos[k] || { s: "", d: "" };
    const coms = String(r[4] || "").split("+").map(function (x) { return x.trim(); }).filter(String);
    const base = { client: filBase_(r[1]), nom_cle: filNomCle_(r[1]), ville: String(r[2] || ""), vendeurs: vend(coms) };
    const note = [String(r[5] || ""), r[10] ? "Équipe : " + r[10] : ""].filter(String).join(" · ");
    if (s === "Planifiée" && d && (av.s !== "Planifiée" || av.d !== d))
      ev.push(Object.assign({}, base, { type: "pose_planifiee", cle: "pose_plan|" + k + "|" + d, date_evt: d, commentaire: note }));
    if (s === "Posée" && av.s !== "Posée")
      ev.push(Object.assign({}, base, { type: "pose_terminee", cle: "pose_ok|" + k, commentaire: String(r[5] || "") }));
    if (s === "SAV" && av.s !== "SAV")
      ev.push(Object.assign({}, base, { type: "sav", cle: "sav|" + k + "|" + (d || filIso_(new Date())), date_evt: d || null, commentaire: String(r[13] || "").slice(0, 300) }));
  });

  // Financements, factures, encaissements
  filLire_("Encaissements").forEach(function (r) {
    if (!r[0]) return;
    const ref = String(r[0]).trim(), s = String(r[5] || ""), av = A.enc[ref] || { s: "", m: 0 };
    if (s === av.s && !(s.indexOf("Encaiss") === 0 && filNum_(r[9]) !== av.m)) return;
    const coms = String(r[2] || "").split("+").map(function (x) { return x.trim(); }).filter(String);
    const fin = String(r[6] || "");
    const orga = FIL_ORGAS.filter(function (o) { return fin.toLowerCase().indexOf(o.toLowerCase()) >= 0; })[0] || (fin ? "" : "");
    const base = { client: filBase_(r[1]), nom_cle: filNomCle_(r[1]), vendeurs: vend(coms), montant: filNum_(r[3]) };
    if (s === "Financement accordé") ev.push(Object.assign({}, base, { type: "financement_ok", cle: "fin_ok|" + ref, organisme: orga || "Sofinco" }));
    else if (s === "Financement refusé") ev.push(Object.assign({}, base, { type: "financement_refus", cle: "fin_ko|" + ref, organisme: orga || "Sofinco", commentaire: String(r[12] || "").slice(0, 300) }));
    else if (s === "Facturé") ev.push(Object.assign({}, base, { type: "facturation", cle: "fact|" + ref, commentaire: r[7] ? "Facture n° " + r[7] : "" }));
    else if (s === "Encaissé" || s === "Encaissé partiel") {
      const m = filNum_(r[9]) || filNum_(r[3]);
      ev.push(Object.assign({}, base, { type: "encaissement", cle: "enc|" + ref + "|" + m, montant: m, commentaire: s === "Encaissé partiel" ? "Encaissement partiel" : "Dossier soldé" }));
    }
  });

  // Classement du mois et objectifs
  const cl = filClassement_();
  const medal = ["🥇", "🥈", "🥉"];
  if (cl.mois === A.mois) {
    if (cl.podium && cl.podium !== A.podium) {
      ev.push({ type: "classement", cle: "podium|" + cl.mois + "|" + cl.podium, client: "Nouveau podium du mois",
        commentaire: cl.rang.slice(0, 3).map(function (v, i) { return medal[i] + " " + filNom_(v) + " " + filEur_(cl.ca[v]); }).join(" · ") });
    }
    Object.keys(cl.atteints).forEach(function (v) {
      if (A.obj && A.obj[v]) return;
      const o = cl.eq[v].obj;
      ev.push({ type: "classement", cle: "obj|" + cl.mois + "|" + v, client: filNom_(v) + " atteint son objectif du mois 🎯",
        commentaire: filEur_(cl.ca[v]) + " HT sur " + filEur_(o) + " (" + Math.round(cl.ca[v] / o * 100) + " %)", vendeurs: vend([v]) });
    });
    if (cl.equipeAtteint && !A.objEq) {
      ev.push({ type: "classement", cle: "objeq|" + cl.mois, client: "Objectif de l'agence atteint ! 🚀",
        commentaire: filEur_(cl.tot) + " HT sur " + filEur_(cl.totObj) + " ce mois-ci. Bravo à toute l'équipe." });
    }
  }

  // Bilan de la semaine : le vendredi à partir de 18 h
  const now = new Date(), semaine = filCleSemaine_(now);
  const heure = +Utilities.formatDate(now, filTz_(), "H"), jour = +Utilities.formatDate(now, filTz_(), "u");
  if (jour === 5 && heure >= 18 && A.bilanEnvoye !== semaine) {
    const st = filStats_().semaine;
    ev.push({ type: "classement", cle: "bilan|" + semaine, client: "Bilan de la semaine",
      commentaire: filEur_(st.ca) + " HT · " + st.ventes + " vente(s) · " + st.pct + " % de l'objectif" +
        (st.annulations ? " · " + st.annulations + " annulation(s)" : "") + (st.top ? " · Meilleur vendeur : " + st.top.nom + " (" + filEur_(st.top.ca) + ")" : "") });
    B.bilanEnvoye = semaine;
  } else {
    B.bilanEnvoye = A.bilanEnvoye || "";
  }
  return ev;
}

/* ===================== Statistiques pour l'espace Coach ===================== */

function filStats_() {
  const eq = filEquipe_(), tz = filTz_();
  const now = new Date();
  const auj = filIso_(now), mois = filMois_(now), lundi = filCleSemaine_(now);
  const fin = new Date(now.getFullYear(), now.getMonth() + 1, 0);
  let joursRestants = 0;
  for (let d = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1); d <= fin; d.setDate(d.getDate() + 1)) if (d.getDay() % 6) joursRestants++;
  const per = {
    jour: function (d) { return filIso_(d) === auj; },
    semaine: function (d) { const i = filIso_(d); return i >= lundi && i <= auj; },
    mois: function (d) { return filMois_(d) === mois; },
  };
  const D = filDossiers_();
  const out = { maj: Utilities.formatDate(now, tz, "dd/MM/yyyy HH:mm"), joursRestants: joursRestants };
  const objMois = {};
  Object.keys(eq).forEach(function (v) { objMois[v] = eq[v].obj || 0; });
  Object.keys(per).forEach(function (p) {
    const vendeurs = {}, canaux = {}, produits = {};
    let ca = 0, ventes = 0, annul = 0, caAnnul = 0;
    Object.keys(D).forEach(function (k) {
      const x = D[k];
      if (!x.date || !per[p](x.date)) return;
      if (x.annule) { annul++; caAnnul += x.ca; return; }
      ventes++; ca += x.ca;
      if (x.canal) canaux[x.canal] = (canaux[x.canal] || 0) + 1;
      if (x.prod) produits[x.prod] = (produits[x.prod] || 0) + 1;
      x.lignes.forEach(function (l) {
        if (l.statut === "Annulé" || !l.com) return;
        const v = vendeurs[l.com] || (vendeurs[l.com] = { nom: filNom_(l.com), ca: 0, ventes: 0 });
        v.ca += l.ca; v.ventes += x.lignes.length > 1 ? 0.5 : 1;
      });
    });
    const f = p === "mois" ? 1 : p === "semaine" ? 12 / 52 : 12 / 52 / 5;
    let obj = 0;
    Object.keys(objMois).forEach(function (v) {
      obj += objMois[v] * f;
      const s = vendeurs[v] || (vendeurs[v] = { nom: filNom_(v), ca: 0, ventes: 0 });
      s.obj = Math.round(objMois[v] * f); s.pct = s.obj ? Math.round(s.ca / s.obj * 100) : 0;
      s.groupe = /apporteur/i.test(eq[v].groupe) ? "Apporteur" : "Équipe";
    });
    const liste = Object.keys(vendeurs).map(function (v) { return vendeurs[v]; }).sort(function (a, b) { return b.ca - a.ca; });
    const top = function (o) { return Object.keys(o).sort(function (a, b) { return o[b] - o[a]; })[0] || ""; };
    out[p] = { ca: Math.round(ca), ventes: ventes, annulations: annul, caAnnule: Math.round(caAnnul), obj: Math.round(obj),
      pct: obj ? Math.round(ca / obj * 100) : 0, panier: ventes ? Math.round(ca / ventes) : 0,
      top: liste[0] && liste[0].ca > 0 ? { nom: liste[0].nom, ca: Math.round(liste[0].ca) } : null,
      vendeurs: liste.map(function (v) { return { nom: v.nom, ca: Math.round(v.ca), ventes: v.ventes, obj: v.obj || 0, pct: v.pct || 0, groupe: v.groupe || "" }; }),
      canal: top(canaux), produit: top(produits) };
  });
  out.mois.reste = Math.max(0, out.mois.obj - out.mois.ca);
  out.mois.parJour = joursRestants ? Math.round(out.mois.reste / joursRestants) : 0;
  let aPlanifier = 0, sav = 0;
  filLire_("Poses").forEach(function (r) { if (r[8] === "À planifier") aPlanifier++; if (r[8] === "SAV") sav++; });
  let aFacturer = 0, finEtude = 0;
  filLire_("Encaissements").forEach(function (r) { if (r[5] === "À facturer") aFacturer++; if (r[5] === "Financement en étude") finEtude++; });
  out.poses = { aPlanifier: aPlanifier, sav: sav };
  out.encaissements = { aFacturer: aFacturer, financementsEnEtude: finEtude };
  return out;
}

/* ===================== Envoi et mémoire ===================== */

function filEnvoyer_(payload) {
  try {
    const r = UrlFetchApp.fetch(FIL_URL, {
      method: "post", contentType: "application/json", muteHttpExceptions: true, followRedirects: false,
      headers: { "X-DCRF-Cle": FIL_CLE }, payload: JSON.stringify(payload),
    });
    const code = r.getResponseCode(), txt = r.getContentText();
    if (code === 200) return { ok: true };
    if (code >= 300 && code < 400) return { ok: false, msg: "redirection vers une page de connexion (Cloudflare Access bloque l'adresse /api/auto)" };
    let m = txt;
    try { m = JSON.parse(txt).erreur || txt; } catch (e) {}
    return { ok: false, msg: "code " + code + " : " + String(m).slice(0, 200) };
  } catch (e) {
    return { ok: false, msg: String(e) };
  }
}

function filFeuille_() {
  const ss = SpreadsheetApp.getActive();
  let sh = ss.getSheetByName(FIL_ETAT);
  if (!sh) { sh = ss.insertSheet(FIL_ETAT); sh.hideSheet(); }
  return sh;
}
function filSauver_(etat) {
  const txt = JSON.stringify(etat), sh = filFeuille_(), parts = [];
  for (let i = 0; i < txt.length; i += 40000) parts.push([txt.slice(i, i + 40000)]);
  sh.clear();
  sh.getRange(1, 1, parts.length, 1).setValues(parts);
}
function filCharger_() {
  const sh = SpreadsheetApp.getActive().getSheetByName(FIL_ETAT);
  if (!sh || sh.getLastRow() < 1) return null;
  const txt = sh.getRange(1, 1, sh.getLastRow(), 1).getValues().map(function (r) { return r[0]; }).join("");
  try { return JSON.parse(txt); } catch (e) { return null; }
}
